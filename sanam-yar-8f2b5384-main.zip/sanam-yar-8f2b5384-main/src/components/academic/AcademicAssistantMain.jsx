
import React, { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { Resource, VeterinaryKnowledge } from "@/api/entities";
import { User } from "@/api/entities";
import { UploadFile } from "@/api/integrations";
import { grokLLM } from "@/api/functions";
import { LearningProfile } from "@/api/entities";
import { numberCitations } from "@/components/utils/citation";
import VirtualList from "@/components/shared/VirtualList.jsx";
import {
    Upload,
    FileText,
    BookHeart,
    Brain,
    Loader2,
    CheckCircle2,
    Sparkles,
    MessageSquare,
    Highlighter,
    Search,
    BookOpen,
    Database,
    TrendingUp,
    ImageIcon,
    AlertTriangle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import KnowledgeProcessor from "@/components/knowledge/KnowledgeProcessor";
import KnowledgeSearch from "@/components/knowledge/KnowledgeSearch";
import FeedbackCollector from "@/components/feedback/FeedbackCollector";
import { AIResponse } from "@/api/entities";
import AdvancedImageProcessor from "@/components/shared/AdvancedImageProcessor";
import GlossaryViewer from "@/components/glossary/GlossaryViewer";

// ADVANCED LRU CACHE WITH PERFORMANCE MONITORING
class AdvancedResponseCache {
    constructor(maxSize = 100, ttl = 10 * 60 * 1000) {
        this.cache = new Map();
        this.maxSize = maxSize;
        this.ttl = ttl;
        this.hitCount = 0;
        this.missCount = 0;
        this.totalResponseTime = 0; // Sum of response times for hits

        // Initialize performance metrics
        this.performanceMetrics = {
            avgResponseTime: 0,
            cacheEfficiency: 0,
            memoryUsage: 0,
            totalRequests: 0,
            hitRate: 0 // Will be updated by getPerformanceStats
        };
    }

    normalizeKey(key) {
        // Advanced key normalization for better cache hits
        if (typeof key === 'string') {
            return key
                .toLowerCase()
                .trim()
                .replace(/[^\p{L}\p{N}\s]/gu, '') // Remove non-alphanumeric/non-space characters, supporting Unicode
                .replace(/\s+/g, '_'); // Replace spaces with underscores
        }
        return String(key);
    }

    get(key) {
        const startTime = performance.now();
        const normalizedKey = this.normalizeKey(key);
        const item = this.cache.get(normalizedKey);
        
        this.performanceMetrics.totalRequests++;

        if (!item) {
            this.missCount++;
            this.updateMetrics();
            return null;
        }

        // TTL validation
        if (Date.now() - item.timestamp > this.ttl) {
            this.cache.delete(normalizedKey);
            this.missCount++;
            this.updateMetrics();
            return null;
        }

        // LRU: Move to end (effectively updates timestamp for access)
        this.cache.delete(normalizedKey);
        item.accessCount++; // Increment access count for intelligent eviction
        this.cache.set(normalizedKey, item);
        this.hitCount++;
        
        const responseTime = performance.now() - startTime;
        this.totalResponseTime += responseTime;
        this.updateMetrics();
        
        return item.data;
    }

    set(key, data) {
        const normalizedKey = this.normalizeKey(key);
        
        // Intelligent eviction: prefer evicting least recently used AND least frequently accessed
        if (this.cache.size >= this.maxSize && !this.cache.has(normalizedKey)) {
            this.evictLeastUsedAndAccessed();
        }

        this.cache.set(normalizedKey, {
            data,
            timestamp: Date.now(),
            accessCount: 1,
            size: this.estimateSize(data)
        });
        this.updateMetrics();
    }

    evictLeastUsedAndAccessed() {
        let leastCandidateKey = null;
        let minScore = Infinity; // Lower score is worse (more likely to be evicted)

        for (const [key, item] of this.cache) {
            // Calculate a score: newer and more accessed items have higher scores
            // Example score: accessCount * (1 - (Date.now() - timestamp) / this.ttl)
            // A simpler score could be (accessCount / (Date.now() - timestamp)) or a weighted sum
            const ageFactor = (Date.now() - item.timestamp) / this.ttl; // 0 for fresh, 1 for expired
            const score = item.accessCount - ageFactor * 10; // Penalize older items

            if (score < minScore) {
                minScore = score;
                leastCandidateKey = key;
            }
        }
        
        if (leastCandidateKey) {
            this.cache.delete(leastCandidateKey);
        }
    }

    estimateSize(data) {
        // More robust size estimation for objects
        try {
            return new TextEncoder().encode(JSON.stringify(data)).length;
        } catch (e) {
            return 0; // Fallback
        }
    }

    updateMetrics() {
        const totalRequests = this.hitCount + this.missCount;
        this.performanceMetrics.totalRequests = totalRequests;
        this.performanceMetrics.cacheEfficiency = totalRequests > 0 
            ? (this.hitCount / totalRequests) * 100 
            : 0;
        
        this.performanceMetrics.avgResponseTime = this.hitCount > 0 
            ? this.totalResponseTime / this.hitCount 
            : 0;

        let totalSize = 0;
        for (const [, item] of this.cache) {
            totalSize += item.size || 0;
        }
        this.performanceMetrics.memoryUsage = totalSize;
    }

    getPerformanceStats() {
        // Ensure metrics are up-to-date before returning
        this.updateMetrics();
        return {
            ...this.performanceMetrics,
            entries: this.cache.size,
            hitRate: this.performanceMetrics.cacheEfficiency, // Renaming for consistency with outline
            totalRequests: this.performanceMetrics.totalRequests // Renaming for consistency with outline
        };
    }

    clear() {
        this.cache.clear();
        this.hitCount = 0;
        this.missCount = 0;
        this.totalResponseTime = 0;
        this.performanceMetrics = {
            avgResponseTime: 0,
            cacheEfficiency: 0,
            memoryUsage: 0,
            totalRequests: 0,
            hitRate: 0
        };
    }
}

// ADVANCED REQUEST DEDUPLICATION SYSTEM
class RequestDeduplicator {
    constructor() {
        this.pendingRequests = new Map();
        this.requestHistory = new Map(); // Stores timestamps of recent requests for frequency limiting
        this.FREQUENCY_LIMIT_MS = 2000; // 2 seconds
        this.MAX_REQUESTS_PER_PERIOD = 3; // Max 3 requests within 2 seconds
    }

    normalizeKey(key) {
        return typeof key === 'string' ? key.toLowerCase().trim() : String(key);
    }

    isRequestTooFrequent(key) {
        const normalizedKey = this.normalizeKey(key);
        const history = this.requestHistory.get(normalizedKey) || [];
        const now = Date.now();
        const recentRequests = history.filter(time => now - time < this.FREQUENCY_LIMIT_MS);
        
        return recentRequests.length >= this.MAX_REQUESTS_PER_PERIOD;
    }

    trackRequest(key) {
        const normalizedKey = this.normalizeKey(key);
        let history = this.requestHistory.get(normalizedKey) || [];
        history.push(Date.now());
        
        // Keep only history from the last minute to prevent infinite growth
        history = history.filter(time => Date.now() - time < 60 * 1000); // 1 minute
        this.requestHistory.set(normalizedKey, history);
    }

    async deduplicate(key, requestFn) {
        const normalizedKey = this.normalizeKey(key);
        
        // Check if request is already pending
        if (this.pendingRequests.has(normalizedKey)) {
            return this.pendingRequests.get(normalizedKey);
        }

        // Check request frequency to prevent spam
        if (this.isRequestTooFrequent(normalizedKey)) {
            throw new Error('درخواست‌های متوالی خیلی سریع. لطفاً کمی صبر کنید.');
        }

        // Create and track new request
        const requestPromise = requestFn().finally(() => {
            this.pendingRequests.delete(normalizedKey);
        });

        this.pendingRequests.set(normalizedKey, requestPromise);
        this.trackRequest(normalizedKey);
        
        return requestPromise;
    }

    abort(key) {
        // This 'abort' only removes it from pending, doesn't actually abort the underlying fetch
        // For this context, it prevents subsequent identical requests from being blocked by a "pending" status.
        const normalizedKey = this.normalizeKey(key);
        this.pendingRequests.delete(normalizedKey);
    }
}

// Helper function to invoke backend functions via API
const invokeBackendFunction = async (name, payload) => {
    const response = await fetch(`/api/functions/${name}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    });
    if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: 'Unknown error' }));
        throw new Error(`Backend function ${name} failed: ${errorData.message || response.statusText}`);
    }
    return await response.json();
};

// DEBOUNCE HOOK WITH ADVANCED CANCELLATION
function useAdvancedDebounce(callback, delay, dependencies = []) {
    const timeoutRef = useRef(null);
    const callbackRef = useRef(callback);
    const mountedRef = useRef(true);

    useEffect(() => {
        callbackRef.current = callback;
    }, [callback]);

    useEffect(() => {
        return () => {
            mountedRef.current = false;
            if (timeoutRef.current) {
                clearTimeout(timeoutRef.current);
            }
        };
    }, []);

    return useCallback((...args) => {
        if (timeoutRef.current) {
            clearTimeout(timeoutRef.current);
        }

        timeoutRef.current = setTimeout(() => {
            if (mountedRef.current) {
                callbackRef.current(...args);
            }
        }, delay);
    }, [delay, ...dependencies]);
}

// GLOBAL INSTANCES
const responseCache = new AdvancedResponseCache(150, 15 * 60 * 1000); // 15 minutes TTL, Max 150 entries
const requestDeduplicator = new RequestDeduplicator();

export default function AcademicAssistantMain() {
    const [resources, setResources] = useState([]);
    const [selectedResource, setSelectedResource] = useState(null);
    const [selectedKnowledge, setSelectedKnowledge] = useState(null);
    const [uploadingFile, setUploadingFile] = useState(null);
    const [status, setStatus] = useState('idle'); // idle, uploading, processing, ready, syncing, error
    const [progress, setProgress] = useState(0);
    const [question, setQuestion] = useState('');
    const [answer, setAnswer] = useState('');
    const [isAnswering, setIsAnswering] = useState(false);
    const [ragResults, setRagResults] = useState(null);
    const [knowledgeStats, setKnowledgeStats] = useState(null);
    const [currentResponseId, setCurrentResponseId] = useState(null);
    const [ocrResult, setOcrResult] = useState(null);
    const [learningProfile, setLearningProfile] = useState(null); // New state for learning profile
    const [performanceStats, setPerformanceStats] = useState(null); // New state for performance monitoring
    const [clarifications, setClarifications] = useState([]); // NEW: dynamic clarifying questions
    
    // mountedRef is used to prevent state updates on unmounted components
    const mountedRef = useRef(true);

    // CLEANUP: Proper component unmount handling
    useEffect(() => {
        return () => {
            mountedRef.current = false;
        };
    }, []);

    // PERFORMANCE STATISTICS UPDATE
    const updatePerformanceStats = useCallback(() => {
        if (mountedRef.current) {
            const cacheStats = responseCache.getPerformanceStats();
            setPerformanceStats(cacheStats);
        }
    }, []);

    // INITIAL DATA LOADING
    useEffect(() => {
        loadResources();
        loadKnowledgeStats();
        loadLearningProfile();
        updatePerformanceStats(); // Initial performance stats load
    }, [updatePerformanceStats]); // Add updatePerformanceStats to dependencies

    // OPTIMIZATION: Memoized resource loading with error boundaries
    const loadResources = useCallback(async () => {
        try {
            const data = await Resource.list('-created_date');
            if (mountedRef.current) {
                setResources(Array.isArray(data) ? data : []);
            }
        } catch (error) {
            console.error('Resource loading failed:', error);
            if (mountedRef.current) {
                setResources([]);
            }
        }
    }, []);

    // New function to load knowledge base statistics
    const loadKnowledgeStats = useCallback(async () => {
        try {
            const statsResponse = await invokeBackendFunction('knowledgeRetriever', {
                action: 'getStats'
            });
            if (mountedRef.current) {
                setKnowledgeStats(statsResponse);
            }
        } catch (error) {
            console.error('خطا در بارگیری آمار کتابخانه:', error);
        }
    }, []);

    const loadLearningProfile = useCallback(async () => {
        try {
            const me = await User.me().catch(() => null);
            const list = await LearningProfile.list();
            const mine = (list || []).find(p => p.created_by === me?.email);
            if (mountedRef.current) {
                setLearningProfile(mine || null);
            }
        } catch (error) {
            console.error("Failed to load learning profile:", error);
        }
    }, []);

    const buildApproachInstruction = useCallback(() => {
        const ap = learningProfile?.approaches || {};
        const blocks = [];
        if (ap.experiential_active) {
            blocks.push("- پاسخ را گام‌به‌گام، کوتاه و عملی ارائه کن؛ در هر گام از صنم جان بخواه انجام دهد یا تأیید کند.");
        }
        if (ap.socratic_active) {
            blocks.push("- قبل از پاسخ نهایی 1-2 پرسش روشن‌کننده بپرس و در انتها جمع‌بندی کن.");
        }
        if (ap.constructivist_active) {
            blocks.push("- مفاهیم را از ساده به پیچیده با تکیه بر دانسته‌های قبلی او شاخ‌وبرگ بده (scaffolding).");
        }
        if (blocks.length === 0) return "";
        return `راهنمای لحن و ساختار پاسخ:
${blocks.join("\n")}
`;
    }, [learningProfile]);

    // Helper: generate clarifications when answer uncertain/short
    const maybeGenerateClarifications = useCallback(async (questionText, contextQuality = null) => {
        // Heuristics: very short answers or low context quality
        if (!questionText) return;
        const isShort = (answer || "").length < 150;
        const lowQuality = typeof contextQuality === 'number' && contextQuality < 60;
        if (!isShort && !lowQuality) {
            setClarifications([]);
            return;
        }
        const prompt = `شما «صنم یار» هستید. کاربر سوالی پرسیده است:
"${questionText}"

لطفاً 2 تا 3 سوال ابهام‌زدا و دقیق برای روشن‌تر شدن مسأله پیشنهاد بده.
فقط هر سوال را در یک خط جداگانه فهرست کن و چیز دیگری ننویس.`;

        try {
            const res = await grokLLM({ prompt });
            const text = res?.data?.reply || res?.reply || "";
            const lines = text.split('\n').map(l => l.trim()).filter(Boolean).slice(0, 3);
            setClarifications(lines);
            // console.debug('[Clarifications] generated', lines);
        } catch (e) {
            // Non-fatal
            setClarifications([]);
        }
    }, [answer]); // `grokLLM` is a stable import, so no need to include in dependencies. `answer` is used for length check.

    const handleFileUpload = useCallback(async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        setUploadingFile(file);
        setStatus('uploading');
        setProgress(0);

        try {
            // File validation
            const maxSize = 50 * 1024 * 1024; // 50MB
            if (file.size > maxSize) {
                throw new Error('فایل بیش از حد بزرگ است (حداکثر 50MB).');
            }

            const allowedTypes = [
                'application/pdf',
                'image/jpeg',
                'image/png',
                'image/jpg',
                'text/plain',
                'application/msword', // .doc
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document' // .docx
            ];

            if (!allowedTypes.includes(file.type)) {
                throw new Error('نوع فایل پشتیبانی نمی‌شود. لطفاً فایل PDF، تصویر یا فایل متنی/ورد آپلود کنید.');
            }

            // 1. Upload file to get URL
            const { file_url } = await UploadFile({ file });
            setProgress(30);

            // 2. Extract content using ExtractDataFromUploadedFile (unified for images and PDFs)
            setStatus('processing');
            setProgress(50);

            let extractedText = '';
            const { ExtractDataFromUploadedFile } = await import('@/api/integrations');
            const result = await ExtractDataFromUploadedFile({
                file_url,
                json_schema: {
                    type: "object",
                    properties: {
                        content: { type: "string" }
                    }
                }
            });
            extractedText = result.output?.content || '';

            if (!extractedText || extractedText.length < 50) {
                throw new Error("محتوای کافی برای تحلیل در فایل یافت نشد.");
            }

            setProgress(70);

            // 3. تحلیل و خلاصه‌سازی محتوا با Grok
            const grokSummaryResponse = await grokLLM({
                prompt: `تو دستیار دامپزشکی "صنم یار" هستی که با کاربرت "صنم جان" صحبت می‌کنی.

این متن تخصصی دامپزشکی را برای صنم جان به زبان فارسی بسیار ساده، روان و دوستانه توضیح بده:

${extractedText}

مهم:
- لحن باید دوستانه و صمیمی باشه
- اصطلاحات پیچیده رو ساده توضیح بده
- از عبارات محاوره‌ای استفاده کن
- مثال‌های عملی بزن
- اگر مطالب جراحی یا پزشکی پیچیده‌ای هست، اون‌ها رو گام‌به‌گام توضیح بده

شروع کن با "صنم جان، ببین این متن چی می‌گه..."`
            });

            const simplifiedContent = grokSummaryResponse.data?.reply || grokSummaryResponse.reply || '';

            setProgress(90);

            // 4. ایجاد منبع در پایگاه داده با متادیتای پیشرفته
            const resourceData = {
                title: file.name || "منبع جدید",
                type: file.type.startsWith('image/') ? 'case_study' : 'textbook',
                category: 'general',
                species: 'general',
                file_url: file_url,
                summary: simplifiedContent,
                tags: ['آپلود شده', 'جدید'],
                difficulty_level: 'intermediate', // Example, could be determined by AI later
                file_size: file.size,
                content_length: extractedText.length,
                processed_at: new Date().toISOString()
            };

            const savedResource = await Resource.create(resourceData);
            if (mountedRef.current) {
                setResources(prev => [savedResource, ...prev]);
                setSelectedResource(savedResource);
            }

            setStatus('ready');
            setProgress(100);
            setUploadingFile(null);
            updatePerformanceStats(); // Update stats after a new resource is added

        } catch (error) {
            console.error("خطا در پردازش فایل:", error);
            if (mountedRef.current) {
                setStatus('error'); // Changed status to 'error' on failure
                setUploadingFile(null);
                setProgress(0);
                // Display error to user
                setAnswer(`خطا در پردازش فایل: ${error.message}`);
            }
        }
    }, [updatePerformanceStats]);

    // PERFORMANCE OPTIMIZATION: Debounced question submission
    const debouncedQuestionSubmit = useAdvancedDebounce(async (questionText) => {
        if (!questionText?.trim() || questionText.trim().length < 3) {
            if (mountedRef.current) {
                setAnswer('لطفاً سوال کاملی وارد کنید (حداقل 3 کاراکتر)');
                setClarifications([]); // Clear clarifications if question is invalid
            }
            return;
        }

        const questionKey = `${questionText}_${selectedResource?.id || 'none'}_${selectedKnowledge?.id || 'none'}`;

        try {
            const responseData = await requestDeduplicator.deduplicate(questionKey, async () => {
                if (mountedRef.current) {
                    setIsAnswering(true);
                    setAnswer('');
                    setRagResults(null);
                    setCurrentResponseId(null);
                    setClarifications([]); // Clear previous clarifications
                }

                // CACHE OPTIMIZATION: Check cache first
                const cachedResponse = responseCache.get(questionKey);
                if (cachedResponse) {
                    // console.log("Cache hit for key:", questionKey);
                    return cachedResponse;
                }
                // console.log("Cache miss for key:", questionKey);

                const approachGuide = buildApproachInstruction();
                const startTime = Date.now();
                let responseContent = '', responseId = null, contextSources = [];
                let retrievedRagResults = null; // Local variable for RAG results

                // TIMEOUT PROTECTION: Add request timeout for API calls
                const timeoutPromise = new Promise((_, reject) => {
                    setTimeout(() => reject(new Error('Request timed out after 25 seconds')), 25000);
                });

                if (selectedResource) {
                    if (!selectedResource.summary || selectedResource.summary.length < 50) {
                        throw new Error('منبع انتخاب شده اطلاعات کافی ندارد');
                    }

                    const contextPrompt = `بر اساس این منبع: "${selectedResource.title}"
محتوای خلاصه: ${selectedResource.summary}
${approachGuide}

سوال صنم جان: ${questionText}

لطفاً به عنوان دستیار دامپزشکی "صنم یار" با لحن دوستانه و آموزشی پاسخ بده:`;

                    const grokResponse = await Promise.race([
                        grokLLM({ prompt: contextPrompt }),
                        timeoutPromise
                    ]);

                    if (!mountedRef.current) throw new Error('Component unmounted'); // Check if still mounted after async op

                    responseContent = grokResponse.data?.reply || grokResponse.reply || '';
                    contextSources = [selectedResource.title];

                } else if (selectedKnowledge) {
                    if (!selectedKnowledge.simplified_content || selectedKnowledge.simplified_content.length < 50) {
                        throw new Error('دانش انتخاب شده اطلاعات کافی ندارد');
                    }

                    const contextPrompt = `بر اساس این دانش: "${selectedKnowledge.title}"
محتوا: ${selectedKnowledge.simplified_content}
${approachGuide}

سوال صنم جان: ${questionText}

لطفاً به عنوان دستیار دامپزشکی "صنم یار" با لحن دوستانه و آموزشی پاسخ بده:`;

                    const grokResponse = await Promise.race([
                        grokLLM({ prompt: contextPrompt }),
                        timeoutPromise
                    ]);

                    if (!mountedRef.current) throw new Error('Component unmounted');

                    responseContent = grokResponse.data?.reply || grokResponse.reply || '';
                    contextSources = [selectedKnowledge.title];

                } else {
                    // RAG OPTIMIZATION: Parallel search with timeout
                    try {
                        const ragPromise = invokeBackendFunction('knowledgeRetriever', {
                            action: 'searchAndAnswer',
                            payload: {
                                query: `${questionText}\n\n${approachGuide}`,
                                options: {
                                    topK: 7, // Retrieve more relevant chunks
                                    language: 'both',
                                    minReliability: 75, // Higher reliability threshold
                                    maxTokens: 4000,
                                    timeout: 20000, // 20s timeout for the backend RAG function
                                    includeMetadata: true // Request metadata for sources
                                }
                            }
                        });

                        const ragResponse = await Promise.race([ragPromise, timeoutPromise]);

                        if (!mountedRef.current) throw new Error('Component unmounted');

                        if (ragResponse?.answer && ragResponse.answer.length > 20) {
                            responseContent = ragResponse.answer;
                            retrievedRagResults = ragResponse; // Store RAG results locally
                            contextSources = ragResponse.sourcesUsed?.map(s => s.title) || [];
                        } else {
                            throw new Error('Insufficient RAG response or no relevant data found');
                        }

                    } catch (ragError) {
                        console.warn('خطا در RAG، fallback به Grok مستقیم:', ragError);
                        
                        const grokResponse = await Promise.race([
                            grokLLM({
                                prompt: `صنم جان این سوال رو پرسیده: ${questionText}\n\n${approachGuide}\n\nبه عنوان دستیار دامپزشکی "صنم یار" با لحن دوستانه پاسخ بده:`
                            }),
                            timeoutPromise
                        ]);

                        if (!mountedRef.current) throw new Error('Component unmounted');

                        responseContent = grokResponse.data?.reply || grokResponse.reply || '';
                        contextSources = ['دانش عمومی Grok'];
                    }
                }

                // VALIDATION: Response quality check
                if (!responseContent || responseContent.length < 10) {
                    throw new Error('پاسخ دریافتی کوتاه یا نامعتبر است');
                }

                // STORAGE: Save response with performance metrics and enhanced metadata
                const responseSaveData = {
                    content: responseContent,
                    prompt_used: questionText,
                    module_type: 'educational',
                    response_time_ms: Date.now() - startTime,
                    context_sources: contextSources,
                    tokens_used: Math.ceil(responseContent.length / 4), // Rough estimation: 1 token ~ 4 chars
                    quality_score: responseContent.length > 100 ? 85 : 70, // Basic quality scoring
                    approach_used: Object.keys(learningProfile?.approaches || {}).filter(key => 
                        learningProfile?.approaches[key]
                    ).join(',') || 'none'
                };

                const aiResponse = await AIResponse.create(responseSaveData);
                responseId = aiResponse.id;

                const resultToCache = {
                    answer: responseContent,
                    ragResults: retrievedRagResults, // Use the locally retrieved RAG results
                    responseId: responseId,
                    contextSources: contextSources,
                    responseTime: Date.now() - startTime
                };

                // CACHE: Store successful response
                responseCache.set(questionKey, resultToCache);
                
                return resultToCache;
            });

            if (mountedRef.current) {
                setAnswer(responseData.answer);
                setCurrentResponseId(responseData.responseId);
                if (responseData.ragResults) {
                    setRagResults(responseData.ragResults);
                }
                updatePerformanceStats(); // Update performance stats after response
            }

        } catch (error) {
            console.error('Question processing error:', error);
            
            if (mountedRef.current) {
                let errorMessage = 'متأسفانه خطایی رخ داد. لطفاً دوباره تلاش کنید.';
                
                if (error.message.includes('Component unmounted')) {
                    // Do nothing if component unmounted while awaiting
                    return;
                } else if (error.message.includes('timed out')) {
                    errorMessage = 'درخواست زمان زیادی طول کشید. لطفاً دوباره تلاش کنید.';
                } else if (error.message.includes('کافی نیست') || error.message.includes('کوتاه یا نامعتبر')) {
                    errorMessage = error.message;
                } else if (error.message.includes('درخواست‌های متوالی خیلی سریع')) {
                    errorMessage = error.message; // Use the specific error message from deduplicator
                } else if (error.message.includes('Insufficient RAG response')) {
                    errorMessage = 'پاسخ مرتبطی در کتابخانه هوشمند یافت نشد، لطفاً سوال خود را تغییر دهید یا منتظر به‌روزرسانی کتابخانه باشید.';
                }
                
                setAnswer(errorMessage);
            }
        } finally {
            if (mountedRef.current) {
                setIsAnswering(false);
            }
        }
    }, 800, [selectedResource, selectedKnowledge, learningProfile, buildApproachInstruction, updatePerformanceStats]); // 800ms debounce

    const handleQuestionSubmit = useCallback(() => {
        debouncedQuestionSubmit(question);
    }, [question, debouncedQuestionSubmit]);

    const handleOCRTextExtracted = useCallback((extractedData) => {
        // Handle OCR extracted text
        if (mountedRef.current) {
            setOcrResult(extractedData);
            // Automatically set the extracted text as a question for further processing
            if (extractedData.correctedText) {
                setQuestion(`تحلیل این متن استخراج شده:\n\n${extractedData.correctedText}`);
            }
        }
    }, []);

    const handleOCRError = useCallback((error) => {
        console.error('خطا در OCR:', error);
        // Could show a toast notification here
    }, []);

    const handleSyncKnowledge = useCallback(async () => {
        // همگام‌سازی کتابخانه: ابتدا جمع‌آوری، سپس پردازش موارد معلق و بروزرسانی آمار
        try {
            if (mountedRef.current) {
                setStatus('syncing');
            }
            
            console.log('شروع جمع‌آوری دانش...');
            const harvestResult = await invokeBackendFunction('knowledgeHarvester', { 
                action: 'harvestAll' 
            });
            console.log('نتیجه جمع‌آوری:', harvestResult);
            
            console.log('پردازش منابع معلق...');
            const processResult = await invokeBackendFunction('knowledgeHarvester', { 
                action: 'processPending' 
            });
            console.log('نتیجه پردازش:', processResult);
            
            // بروزرسانی آمار
            await loadKnowledgeStats();
            
            if (mountedRef.current) {
                setStatus('ready');
            }
        } catch (error) {
            console.error('خطا در همگام‌سازی کتابخانه:', error);
            if (mountedRef.current) {
                setStatus('error');
            }
        }
    }, [loadKnowledgeStats]);

    // After answer or ragResults change, maybe propose clarifications
    useEffect(() => {
        if (question && (answer || ragResults)) {
            const contextQ = ragResults?.contextQuality ?? null;
            maybeGenerateClarifications(question, contextQ);
        }
    }, [answer, ragResults, question, maybeGenerateClarifications]);

    return (
        <div className="space-y-8">
            <div>
                <h1 className="text-3xl font-bold text-gray-800 mb-2">دستیار تحصیلی</h1>
                <p className="text-gray-600">صنم جان، بیا با هم یاد بگیریم! هر سوالی داری بپرس 💕</p>
            </div>

            {/* Performance Statistics Display */}
            {performanceStats && (
                <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-0 shadow-md">
                    <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-2">
                            <h3 className="font-bold text-green-800 flex items-center gap-2">
                                <TrendingUp className="w-5 h-5" /> آمار عملکرد سیستم
                            </h3>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div className="text-center">
                                <div className="text-xl font-bold text-green-600">
                                    {Math.round(performanceStats.cacheEfficiency)}%
                                </div>
                                <div className="text-gray-600">راندمان کش</div>
                            </div>
                            <div className="text-center">
                                <div className="text-xl font-bold text-blue-600">
                                    {Math.round(performanceStats.avgResponseTime)}ms
                                </div>
                                <div className="text-gray-600">میانگین پاسخ</div>
                            </div>
                            <div className="text-center">
                                <div className="text-xl font-bold text-purple-600">
                                    {performanceStats.entries}
                                </div>
                                <div className="text-gray-600">پاسخ‌های کش شده</div>
                            </div>
                            <div className="text-center">
                                <div className="text-xl font-bold text-orange-600">
                                    {Math.round(performanceStats.memoryUsage / 1024)}KB
                                </div>
                                <div className="text-gray-600">مصرف حافظه</div>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* نمایش آمار کتابخانه هوشمند */}
            {knowledgeStats && (
                <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-0"
                      style={{
                          boxShadow: 'inset -2px -2px 8px rgba(59, 130, 246, 0.15), inset 2px 2px 8px rgba(255, 255, 255, 0.9)'
                      }}>
                    <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-4">
                                <Database className="w-6 h-6 text-blue-600" />
                                <h3 className="text-lg font-bold text-blue-800">کتابخانه هوشمند صنم یار</h3>
                            </div>
                            <Button 
                                variant="outline" 
                                size="sm" 
                                onClick={handleSyncKnowledge} 
                                className="rounded-xl"
                                disabled={status === 'syncing'}
                            >
                                {status === 'syncing' ? (
                                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                                ) : (
                                    <BookOpen className="w-4 h-4 mr-2" />
                                )}
                                همگام‌سازی کتابخانه
                            </Button>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div className="text-center">
                                <div className="text-2xl font-bold text-blue-600">{knowledgeStats.totalSources || 0}</div>
                                <div className="text-gray-600">منبع علمی</div>
                            </div>
                            <div className="text-center">
                                <div className="text-2xl font-bold text-purple-600">{knowledgeStats.totalChunks || 0}</div>
                                <div className="text-gray-600">بخش دانش</div>
                            </div>
                            <div className="text-center">
                                <div className="text-2xl font-bold text-green-600">{knowledgeStats.avgReliability?.toFixed(0) || 0}%</div>
                                <div className="text-gray-600">میانگین اعتبار</div>
                            </div>
                            <div className="text-center">
                                <div className="text-2xl font-bold text-rose-600">
                                    {knowledgeStats.languageDistribution?.persian || 0}
                                </div>
                                <div className="text-gray-600">منبع فارسی</div>
                            </div>
                        </div>
                        {status === 'syncing' && (
                            <Alert className="mt-4 rounded-xl bg-blue-50 border-blue-200 text-blue-800">
                                <AlertDescription className="flex items-center gap-2">
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                    <p>در حال همگام‌سازی کتابخانه...</p>
                                </AlertDescription>
                            </Alert>
                        )}
                        {status === 'error' && (
                            <Alert className="mt-4 rounded-xl bg-red-50 border-red-200 text-red-800">
                                <AlertDescription className="flex items-center gap-2">
                                    <AlertTriangle className="h-4 w-4" />
                                    <p>خطا در همگام‌سازی کتابخانه!</p>
                                </AlertDescription>
                            </Alert>
                        )}
                    </CardContent>
                </Card>
            )}

            <Tabs defaultValue="rag-search" className="w-full">
                <TabsList className="grid w-full grid-cols-6 rounded-2xl bg-pink-100/50">
                    <TabsTrigger value="rag-search" className="rounded-2xl">جستجوی هوشمند</TabsTrigger>
                    <TabsTrigger value="upload" className="rounded-2xl">آپلود و مطالعه</TabsTrigger>
                    <TabsTrigger value="knowledge" className="rounded-2xl">کتابخانه دانش</TabsTrigger>
                    <TabsTrigger value="process" className="rounded-2xl">پردازش متن انگلیسی</TabsTrigger>
                    <TabsTrigger value="ocr" className="rounded-2xl">OCR پیشرفته</TabsTrigger>
                    <TabsTrigger value="glossary" className="rounded-2xl">فرهنگ اصطلاحات</TabsTrigger>
                </TabsList>

                <TabsContent value="rag-search" className="space-y-6">
                    <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border-0"
                          style={{
                              boxShadow: 'inset -3px -3px 10px rgba(59, 130, 246, 0.15), inset 3px 3px 10px rgba(255, 255, 255, 0.9)'
                          }}>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-3 text-blue-800">
                                <Search className="w-6 h-6" />
                                جستجوی هوشمند در کتابخانه
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <p className="text-blue-700 text-sm">
                                صنم جان، سوالت رو بپرس تا از هزاران منبع معتبر دامپزشکی جواب بگیری! 🔍📚
                            </p>

                            <Textarea
                                placeholder="مثلاً: علت اصلی استفراغ در گربه‌ها چیه؟ یا روش‌های جراحی اخصا در سگ‌ها"
                                value={question}
                                onChange={(e) => setQuestion(e.target.value)}
                                rows={3}
                                className="rounded-2xl border-blue-200"
                            />

                            <Button
                                onClick={handleQuestionSubmit}
                                disabled={isAnswering || !question.trim()}
                                className="w-full rounded-2xl bg-gradient-to-r from-blue-500 to-purple-500"
                            >
                                {isAnswering ? <Loader2 className="w-4 h-4 animate-spin mr-2"/> : <Search className="w-4 h-4 mr-2" />}
                                جستجو و دریافت پاسخ
                            </Button>

                            {/* NEW: Clarification suggestions */}
                            {clarifications.length > 0 && (
                                <div className="p-3 rounded-2xl bg-yellow-50 border border-yellow-200">
                                    <div className="text-sm font-semibold text-yellow-800 mb-2">
                                        برای پاسخ دقیق‌تر، می‌تونی این سوال‌ها رو هم مشخص کنی:
                                    </div>
                                    <div className="flex flex-col gap-2">
                                        {clarifications.map((c, idx) => (
                                            <button
                                                key={idx}
                                                onClick={() => setQuestion(prev => prev ? `${prev}\n\n${c}` : c)}
                                                className="text-right px-3 py-2 rounded-xl bg-white hover:bg-yellow-100 text-gray-800 transition"
                                            >
                                                {c}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {answer && (
                                <div className="space-y-4">
                                    <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200">
                                        <h4 className="font-bold text-blue-800 mb-2">پاسخ صنم یار:</h4>
                                        <p className="whitespace-pre-line leading-relaxed text-gray-800">{answer}</p>
                                    </div>

                                    {/* Add Feedback Collector */}
                                    {currentResponseId && (
                                        <FeedbackCollector
                                            responseId={currentResponseId}
                                            responseContent={answer}
                                            moduleType="educational"
                                            onFeedbackSubmitted={(feedback) => {
                                                console.log('بازخورد ثبت شد:', feedback);
                                                // Optional: You might want to update UI or show a toast here
                                            }}
                                        />
                                    )}

                                    {ragResults && ragResults.sourcesUsed && ragResults.sourcesUsed.length > 0 && (
                                        <div className="p-4 rounded-2xl bg-green-50 border border-green-200">
                                            <h4 className="font-bold text-green-800 mb-3 flex items-center gap-2">
                                                <CheckCircle2 className="w-5 h-5" />
                                                منابع استفاده شده ({ragResults.sourcesUsed.length} منبع):
                                            </h4>
                                            <div className="space-y-2">
                                                {ragResults.sourcesUsed.map((source, index) => (
                                                    <div key={index} className="flex items-center justify-between p-2 bg-white rounded-lg">
                                                        <div>
                                                            <div className="font-medium text-sm">{source.title}</div>
                                                            <div className="text-xs text-gray-600 mt-1">
                                                                {source.author ? `${source.author} ` : ''}
                                                                {source.year ? `(${source.year})` : ''}
                                                            </div>
                                                        </div>
                                                        {source.reliability && (
                                                            <Badge className="bg-green-100 text-green-800">
                                                                اعتبار {source.reliability}%
                                                            </Badge>
                                                        )}
                                                    </div>
                                                ))}
                                            </div>

                                            {/* استنادها (APA ساده) */}
                                            <div className="mt-4 p-3 rounded-xl bg-white">
                                                <div className="text-sm font-semibold text-green-800 mb-2">استنادها</div>
                                                <ul className="list-disc pr-5 text-xs text-gray-700 space-y-1">
                                                    {(ragResults.citations
                                                      ? ragResults.citations.map(c => c.text)
                                                      : numberCitations(ragResults.sourcesUsed)
                                                    ).map((c, i) => (
                                                        <li key={i}>{typeof c === 'string' ? c : c}</li>
                                                    ))}
                                                </ul>
                                            </div>

                                            {ragResults.contextQuality && (
                                                <div className="mt-3 text-xs text-green-600 flex items-center gap-1">
                                                    <TrendingUp className="w-3 h-3" />
                                                    کیفیت پاسخ: {ragResults.contextQuality}%
                                                </div>
                                            )}
                                        </div>
                                    )}

                                    {ragResults && ragResults.note && (
                                        <Alert className="rounded-2xl bg-yellow-50 border-yellow-200 text-yellow-800">
                                            <AlertDescription>{ragResults.note}</AlertDescription>
                                        </Alert>
                                    )}
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="upload" className="space-y-6">
                    <div className="grid lg:grid-cols-3 gap-8">
                        {/* Left Panel: Library and Upload */}
                        <div className="lg:col-span-1 space-y-6">
                            <Card className="bg-white/60 backdrop-blur-sm border-0"
                                  style={{
                                      boxShadow: 'inset -3px -3px 10px rgba(236, 72, 153, 0.15), inset 3px 3px 10px rgba(255, 255, 255, 0.9)'
                                  }}>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-3 text-pink-700">
                                        <Upload className="w-5 h-5" /> آپلود فایل جدید
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="border-2 border-dashed border-rose-200 rounded-3xl p-6 text-center">
                                        <BookHeart className="w-16 h-16 text-rose-300 mx-auto mb-4" />
                                        <p className="text-gray-600 mb-4">
                                            صنم جان, کتاب, جزوه یا عکس جزوات دست‌نویس‌ت رو اینجا بذار
                                        </p>
                                        <input type="file" id="resource-upload" className="hidden" onChange={handleFileUpload} disabled={status !== 'idle' && status !== 'ready' && status !== 'error'} accept=".pdf,.png,.jpg,.jpeg,.txt,.doc,.docx" />
                                        <Button asChild className="rounded-2xl bg-gradient-to-r from-pink-500 to-rose-500">
                                            <Label htmlFor="resource-upload">انتخاب فایل</Label>
                                        </Button>
                                    </div>
                                    {status !== 'idle' && status !== 'ready' && status !== 'error' && (
                                        <div className="mt-4 space-y-2">
                                            <p className="text-center text-pink-600 font-medium">
                                                {status === 'uploading' && `دارم ${uploadingFile?.name} رو آپلود می‌کنم...`}
                                                {status === 'processing' && 'دارم فایلت رو پردازش می‌کنم صنم جان...'}
                                            </p>
                                            <Progress value={progress} className="w-full" />
                                        </div>
                                    )}
                                    {status === 'error' && (
                                        <Alert className="mt-4 rounded-xl bg-red-50 border-red-200 text-red-800">
                                            <AlertDescription className="flex items-center gap-2">
                                                <AlertTriangle className="h-4 w-4" />
                                                <p>{answer || 'خطا در پردازش فایل!'}</p>
                                            </AlertDescription>
                                        </Alert>
                                    )}
                                    <Alert className="mt-4 rounded-2xl bg-fuchsia-50 border-fuchsia-200 text-fuchsia-800">
                                        <Sparkles className="h-4 w-4" />
                                        <AlertDescription>
                                            می‌تونم جزوات دست‌نویس‌ت رو هم بخونم ولی ممکنه همه چیز کامل نباشه
                                        </AlertDescription>
                                    </Alert>
                                </CardContent>
                            </Card>

                            <Card className="bg-white/60 backdrop-blur-sm border-0"
                                  style={{
                                      boxShadow: 'inset -3px -3px 10px rgba(236, 72, 153, 0.15), inset 3px 3px 10px rgba(255, 255, 255, 0.9)'
                                  }}>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-3 text-pink-700">
                                        <BookHeart className="w-5 h-5" /> فایل‌های آپلود شده
                                    </CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-3">
                                    {resources.length === 0 ? (
                                        <p className="text-center text-gray-500">هنوز فایلی آپلود نکردی صنم جان.</p>
                                    ) : (
                                        <div className="h-[60vh] md:h-96 rounded-2xl">
                                            <VirtualList
                                                items={resources}
                                                itemHeight={72} // Adjust based on the actual height of each resource item
                                                overscan={8}
                                                className="h-full"
                                                renderItem={(res) => (
                                                    <div
                                                      key={res.id}
                                                      onClick={() => setSelectedResource(res)}
                                                      className={`p-4 rounded-2xl cursor-pointer transition-all duration-300 ${
                                                          selectedResource?.id === res.id
                                                            ? 'bg-rose-100 shadow-inner'
                                                            : 'bg-gray-50 hover:bg-rose-50'
                                                      }`}
                                                    >
                                                      <p className="font-medium text-gray-800 flex items-center gap-2">
                                                        <FileText className="w-4 h-4 text-rose-500" />
                                                        {res.title}
                                                      </p>
                                                    </div>
                                                )}
                                            />
                                        </div>
                                    )}
                                </CardContent>
                            </Card>
                        </div>

                        {/* Right Panel: Resource Viewer */}
                        <div className="lg:col-span-2">
                            {selectedResource ? (
                                <Card className="bg-white/80 backdrop-blur-xl border-0"
                                      style={{
                                          boxShadow: 'inset -4px -4px 16px rgba(236, 72, 153, 0.1), inset 4px 4px 16px rgba(255, 255, 255, 0.9), 0 8px 32px rgba(236, 72, 153, 0.12)'
                                      }}>
                                    <CardHeader>
                                        <CardTitle className="text-2xl text-fuchsia-800">{selectedResource.title}</CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        <div>
                                            <h3 className="font-bold text-lg mb-3 flex items-center gap-2 text-rose-700">
                                                <Sparkles className="w-5 h-5"/> خلاصه دوستانه
                                            </h3>
                                            <div className="p-4 rounded-2xl bg-rose-50 max-h-60 overflow-y-auto">
                                                <p className="whitespace-pre-line leading-relaxed text-gray-700">{selectedResource.summary}</p>
                                            </div>
                                        </div>
                                        <div className="space-y-3">
                                            <h3 className="font-bold text-lg flex items-center gap-2 text-fuchsia-700">
                                                <MessageSquare className="w-5 h-5" /> سوال بپرس
                                            </h3>
                                            <Textarea
                                                placeholder="صنم جان، سوالت رو از این کتاب بپرس..."
                                                value={question}
                                                onChange={(e) => setQuestion(e.target.value)}
                                                className="rounded-2xl"
                                            />
                                            <Button onClick={handleQuestionSubmit} disabled={isAnswering || !question.trim()} className="rounded-2xl bg-gradient-to-r from-fuchsia-500 to-purple-500">
                                                {isAnswering ? <Loader2 className="w-4 h-4 animate-spin mr-2"/> : <MessageSquare className="w-4 h-4 mr-2" />}
                                                دریافت پاسخ
                                            </Button>
                                            {answer && (
                                                <div className="p-4 rounded-2xl bg-fuchsia-50 border border-fuchsia-200">
                                                    <p className="whitespace-pre-line leading-relaxed text-gray-800">{answer}</p>
                                                </div>
                                            )}
                                        </div>
                                    </CardContent>
                                </Card>
                            ) : (
                                <div className="flex items-center justify-center h-full rounded-3xl bg-white/50 border-2 border-dashed border-rose-200 min-h-[300px]">
                                    <div className="text-center text-rose-500">
                                        <BookHeart className="w-24 h-24 mx-auto mb-4 opacity-50"/>
                                        <p className="text-xl font-medium">صنم جان، یک فایل انتخاب کن</p>
                                        <p>یا یک فایل جدید آپلود کن تا شروع کنیم</p>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </TabsContent>

                <TabsContent value="knowledge" className="space-y-6">
                    <KnowledgeSearch onKnowledgeSelect={(knowledge) => {
                        if (mountedRef.current) {
                            setSelectedKnowledge(knowledge);
                            setSelectedResource(null);
                        }
                    }} />

                    {selectedKnowledge && (
                        <Card className="bg-white/90 backdrop-blur-lg border-0"
                              style={{
                                  boxShadow: 'inset -4px -4px 16px rgba(59, 130, 246, 0.15), inset 4px 4px 16px rgba(255, 255, 255, 0.9), 0 8px 32px rgba(59, 130, 246, 0.12)'
                              }}>
                            <CardHeader>
                                <CardTitle className="text-blue-800">{selectedKnowledge.title}</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200">
                                    <p className="whitespace-pre-line leading-relaxed text-gray-800">
                                        {selectedKnowledge.simplified_content}
                                    </p>
                                </div>

                                {selectedKnowledge.key_concepts?.length > 0 && (
                                    <div>
                                        <h3 className="font-bold text-lg mb-3 text-blue-700">مفاهیم کلیدی:</h3>
                                        <div className="space-y-3">
                                            {selectedKnowledge.key_concepts.map((concept, index) => (
                                                <div key={index} className="p-3 rounded-2xl bg-blue-50/50 border border-blue-100">
                                                    <h4 className="font-medium text-gray-800">{concept.concept}</h4>
                                                    <p className="text-sm text-gray-600 mt-1">{concept.definition_persian}</p>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                )}

                                <div className="space-y-3">
                                    <h3 className="font-bold text-lg flex items-center gap-2 text-blue-700">
                                        <MessageSquare className="w-5 h-5" /> سوال بپرس
                                    </h3>
                                    <Textarea
                                        placeholder="درباره این موضوع سوال داری؟ بپرس صنم جان..."
                                        value={question}
                                        onChange={(e) => setQuestion(e.target.value)}
                                        className="rounded-2xl"
                                    />
                                    <Button onClick={handleQuestionSubmit} disabled={isAnswering || !question.trim()} className="rounded-2xl bg-gradient-to-r from-blue-500 to-purple-500">
                                        {isAnswering ? <Loader2 className="w-4 h-4 animate-spin mr-2"/> : <MessageSquare className="w-4 h-4 mr-2" />}
                                        دریافت پاسخ
                                    </Button>
                                    {/* Inject clarification suggestions also here for knowledge-based Q&A */}
                                    {clarifications.length > 0 && (
                                        <div className="p-3 rounded-2xl bg-yellow-50 border border-yellow-200">
                                            <div className="text-sm font-semibold text-yellow-800 mb-2">
                                                برای دقیق‌تر شدن، این سوال‌ها هم می‌تونن کمک کنن:
                                            </div>
                                            <div className="flex flex-col gap-2">
                                                {clarifications.map((c, idx) => (
                                                    <button
                                                        key={idx}
                                                        onClick={() => setQuestion(prev => prev ? `${prev}\n\n${c}` : c)}
                                                        className="text-right px-3 py-2 rounded-xl bg-white hover:bg-yellow-100 text-gray-800 transition"
                                                    >
                                                        {c}
                                                    </button>
                                                ))}
                                            </div>
                                        </div>
                                    )}
                                    {answer && (
                                        <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200">
                                            <p className="whitespace-pre-line leading-relaxed text-gray-800">{answer}</p>
                                        </div>
                                    )}
                                </div>
                            </CardContent>
                        </Card>
                    )}
                </TabsContent>

                <TabsContent value="process" className="space-y-6">
                    <KnowledgeProcessor onKnowledgeAdded={(knowledge) => {
                        if (mountedRef.current) {
                            setSelectedKnowledge(knowledge);
                            setSelectedResource(null);
                        }
                    }} />
                </TabsContent>

                <TabsContent value="ocr" className="space-y-6">
                    <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-0"
                          style={{
                              boxShadow: 'inset -3px -3px 10px rgba(168, 85, 247, 0.15), inset 3px 3px 10px rgba(255, 255, 255, 0.9)'
                          }}>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-3 text-purple-800">
                                <ImageIcon className="w-6 h-6" />
                                OCR پیشرفته فارسی
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-purple-700 text-sm mb-4">
                                صنم جان، عکس از جزوات، کتاب یا متن دست‌نویس‌ت رو اینجا قرار بده تا با دقت بالا متن رو استخراج کنم! 📷📝
                            </p>

                            <AdvancedImageProcessor
                                onTextExtracted={handleOCRTextExtracted}
                                onError={handleOCRError}
                                className="mb-6"
                            />

                            {ocrResult && (
                                <div className="space-y-4">
                                    <div className="p-4 rounded-2xl bg-green-50 border border-green-200">
                                        <h4 className="font-bold text-green-800 mb-2">✅ متن با موفقیت استخراج شد!</h4>
                                        <p className="text-sm text-green-700 mb-3">
                                            اطمینان: {ocrResult.confidence?.toFixed(1) || 0}% |
                                            متن اصلاح شده آماده است برای تحلیل بیشتر.
                                        </p>

                                        {ocrResult.result?.veterinary_terms_found?.length > 0 && (
                                            <div className="mb-3">
                                                <span className="text-sm font-medium text-green-800">اصطلاحات دامپزشکی شناسایی شده:</span>
                                                <div className="flex flex-wrap gap-1 mt-1">
                                                    {ocrResult.result.veterinary_terms_found.map((term, i) => (
                                                        <Badge key={i} className="bg-green-100 text-green-700 text-xs">
                                                            {term}
                                                        </Badge>
                                                    ))}
                                                </div>
                                            </div>
                                        )}

                                        <Button
                                            onClick={handleQuestionSubmit}
                                            className="bg-green-600 hover:bg-green-700"
                                            disabled={isAnswering}
                                        >
                                            <MessageSquare className="w-4 h-4 mr-2" />
                                            تحلیل متن استخراج شده
                                        </Button>
                                    </div>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="glossary" className="space-y-6">
                    <GlossaryViewer />
                </TabsContent>
            </Tabs>
        </div>
    );
}
